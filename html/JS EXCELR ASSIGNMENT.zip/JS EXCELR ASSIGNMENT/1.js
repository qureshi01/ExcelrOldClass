console.log("Num1 is greater");
let i =0;
while(i<5){
    console.log("While loop iteration "+(i+1));
    i++;
}
for(let i=0;i<5;i++){
    console.log("For loop iteration "+(i+1));
}
let j=0;
do {
    console.log("Do-While loop iteration "+(j+1));
    j++;
  }
while (j < 5);
console.log("It's Monday")