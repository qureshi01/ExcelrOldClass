//Fetching all the variables from html

const minutes = document.getElementById("timer");
const breakt = document.getElementById("break");
let timersubmit = document.getElementById("btn_submit");
var dec_btn = document.getElementById("dec");

//Intializing all the variables 

let count_timer = null;
let breaktime = null;

//Setting the start

const d = new Date();
d.setMinutes(25);
let min = d.getMinutes();
minutes.innerHTML=min;
const e = new Date();
e.setUTCSeconds(59);
let sec = e.getUTCSeconds();
minutes.innerHTML=min + ":" +sec;

//Start the timer

function start_timer(){
    timersubmit.setAttribute("id","stop");
    console.log(timersubmit.getAttribute("id"));
    timersubmit.textContent="STOP"
    sec=sec-1;
    if(sec==0){
        min=min-1;
        sec=59;
        if(min==-1){
            minutes.innerHTML="Its BreakTime";

          timersubmit.setAttribute("id","start");
          console.log(timersubmit.getAttribute("id"));
          timersubmit.textContent="START";
          clearTimeout(count_timer);
        }
    }
    else{
        minutes.innerHTML=min+":"+sec;
    }  
}

//to run timer

function start(){
    count_timer=setInterval(start_timer,1000);
}

//Reset

function reset(){
    d.setMinutes(25);
    min=d.getMinutes();
    e.setSeconds(59);
    sec=e.getSeconds();
    minutes.innerHTML=min+":"+sec;
}

//Stop

function stop(){
    clearTimeout(count_timer);
}
  